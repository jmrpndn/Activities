# CoolTech Services - Refrigeration & Air Conditioning App

A comprehensive Flutter application for a refrigeration and air conditioning services business, featuring modern UI design, state management, and multimedia capabilities.

## Features

### 🏠 Home Screen
- Professional business branding with gradient design
- Service overview cards
- Quick access to booking and services
- Shopping cart integration with badge notifications

### 🔐 Authentication
- **Login Screen**: Email/password authentication with validation
- **Registration Screen**: Complete user registration with role selection
- Form validation for all input fields
- Terms and conditions agreement

### 🛠️ Services Management
- **Services Catalog**: Grid view of available services
- **Service Categories**: Filter by installation, repair, maintenance, etc.
- **Shopping Cart**: Add/remove services, quantity management
- **Search Functionality**: Find services by name or description

### 📅 Booking System
- **Service Booking Form**: Complete booking with date/time selection
- **Priority Levels**: Normal, High, Urgent, Emergency
- **Contact Information**: Name, email, phone, address
- **Service Description**: Detailed problem description
- **Date/Time Pickers**: Intuitive scheduling interface

### 🎥 Media Gallery
- **Video Player**: Service demonstration videos with Chewie controls
- **Audio Player**: Service information audio with custom controls
- **Image Gallery**: Service showcase with category filtering
- **Professional Media**: High-quality business imagery

### 👤 User Profile
- **Profile Management**: Edit personal information
- **Theme Toggle**: Switch between light and dark modes
- **Settings**: Notification preferences, language selection
- **Logout Functionality**: Secure session management

### 🎨 UI/UX Features
- **Material Design 3**: Modern, professional interface
- **Custom Color Scheme**: Green theme representing HVAC industry
- **Responsive Design**: Works on all screen sizes
- **Smooth Animations**: Polished user experience
- **Custom Fonts**: Poppins and Roboto typography

### 🔧 Technical Features
- **State Management**: Provider pattern for app state
- **Navigation**: Bottom tabs, drawer, and named routes
- **Form Validation**: Comprehensive input validation
- **Media Handling**: Video, audio, and image support
- **Theme Management**: Dynamic light/dark theme switching

## Architecture

### State Management
- **ThemeProvider**: Manages app theme and dark mode
- **CartProvider**: Handles shopping cart state
- **UserProvider**: Manages user authentication and profile

### Navigation Structure
- **Bottom Navigation**: Home, Services, Booking, Media, Profile
- **Drawer Menu**: Additional navigation options
- **Named Routes**: Clean navigation management

### Screen Organization
```
lib/
├── main.dart                 # App entry point
├── providers/               # State management
│   ├── theme_provider.dart
│   ├── cart_provider.dart
│   └── user_provider.dart
├── screens/                 # App screens
│   ├── login_screen.dart
│   ├── registration_screen.dart
│   ├── home_screen.dart
│   ├── services_screen.dart
│   ├── booking_screen.dart
│   ├── cart_screen.dart
│   ├── media_screen.dart
│   └── profile_screen.dart
├── widgets/                 # Reusable widgets
│   └── custom_text_field.dart
└── models/                  # Data models
    └── service_data.dart
```

## Dependencies

- **provider**: State management
- **video_player**: Video playback
- **chewie**: Video player controls
- **audioplayers**: Audio playback
- **google_fonts**: Custom typography
- **intl**: Internationalization and date formatting

## Getting Started

1. **Install Dependencies**
   ```bash
   flutter pub get
   ```

2. **Run the App**
   ```bash
   flutter run
   ```

3. **Test Features**
   - Register a new account
   - Browse services and add to cart
   - Book a service appointment
   - Explore media gallery
   - Toggle theme settings

## Business Features

### Service Categories
- AC Installation
- Refrigerator Repair
- AC Maintenance
- Freezer Repair
- Duct Cleaning
- Emergency Services

### User Roles
- Customer
- Admin
- Technician

### Priority Levels
- Low
- Normal
- High
- Urgent

## Design Philosophy

The app follows a professional, clean design approach suitable for a technical service business:

- **Color Scheme**: Green tones representing environmental cooling
- **Typography**: Clean, readable fonts (Poppins, Roboto)
- **Layout**: Card-based design with proper spacing
- **Icons**: Material Design icons for consistency
- **Animations**: Subtle, purposeful transitions

## Future Enhancements

- Payment integration
- Push notifications
- Real-time chat support
- Service tracking
- Customer reviews
- Technician scheduling
- Invoice generation

---

**CoolTech Services** - Professional HVAC Solutions for Your Home and Business