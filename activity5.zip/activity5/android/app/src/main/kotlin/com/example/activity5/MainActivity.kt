package com.example.activity5

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
