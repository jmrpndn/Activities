import 'package:flutter/material.dart';

class ServiceItem {
  final String id;
  final String name;
  final String description;
  final double price;
  final String imageUrl;
  final String category;

  ServiceItem({
    required this.id,
    required this.name,
    required this.description,
    required this.price,
    required this.imageUrl,
    required this.category,
  });
}

class CartItem {
  final ServiceItem service;
  int quantity;

  CartItem({required this.service, this.quantity = 1});

  double get totalPrice => service.price * quantity;
}

class CartProvider extends ChangeNotifier {
  final List<CartItem> _items = [];

  List<CartItem> get items => _items;

  int get itemCount => _items.fold(0, (sum, item) => sum + item.quantity);

  double get totalPrice =>
      _items.fold(0.0, (sum, item) => sum + item.totalPrice);

  void addItem(ServiceItem service) {
    final existingIndex = _items.indexWhere(
      (item) => item.service.id == service.id,
    );

    if (existingIndex >= 0) {
      _items[existingIndex].quantity++;
    } else {
      _items.add(CartItem(service: service));
    }
    notifyListeners();
  }

  void removeItem(String serviceId) {
    _items.removeWhere((item) => item.service.id == serviceId);
    notifyListeners();
  }

  void updateQuantity(String serviceId, int quantity) {
    final index = _items.indexWhere((item) => item.service.id == serviceId);
    if (index >= 0) {
      if (quantity <= 0) {
        _items.removeAt(index);
      } else {
        _items[index].quantity = quantity;
      }
      notifyListeners();
    }
  }

  void clearCart() {
    _items.clear();
    notifyListeners();
  }
}
