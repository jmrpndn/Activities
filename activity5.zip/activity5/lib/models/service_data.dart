import '../providers/cart_provider.dart';

class ServiceData {
  static List<ServiceItem> getServices() {
    return [
      ServiceItem(
        id: '1',
        name: 'AC Installation',
        description:
            'Professional air conditioning unit installation with warranty',
        price: 25000.00,
        imageUrl: 'assets/images/AC Installation.jpg',
        category: 'Installation',
      ),
      ServiceItem(
        id: '2',
        name: 'Refrigerator Repair',
        description: 'Complete refrigerator diagnostic and repair service',
        price: 3500.00,
        imageUrl: 'assets/images/Refrigerator Repair.jpeg',
        category: 'Repair',
      ),
      ServiceItem(
        id: '3',
        name: 'AC Maintenance',
        description: 'Regular maintenance to keep your AC running efficiently',
        price: 2500.00,
        imageUrl: 'assets/images/AC Maintenance.jpg',
        category: 'Maintenance',
      ),
      ServiceItem(
        id: '4',
        name: 'Freezer Repair',
        description: 'Professional freezer repair and maintenance service',
        price: 4000.00,
        imageUrl: 'assets/images/Freezer Repair.jpg',
        category: 'Repair',
      ),
      ServiceItem(
        id: '5',
        name: 'Duct Cleaning',
        description: 'Complete HVAC duct cleaning and sanitization',
        price: 8000.00,
        imageUrl: 'assets/images/Duct Cleaning.jpg',
        category: 'Cleaning',
      ),
      ServiceItem(
        id: '6',
        name: 'Emergency Service',
        description: '24/7 emergency refrigeration and AC repair service',
        price: 12000.00,
        imageUrl: 'assets/images/Emergency Service.png',
        category: 'Emergency',
      ),
    ];
  }

  static List<String> getCategories() {
    return [
      'All',
      'Installation',
      'Repair',
      'Maintenance',
      'Cleaning',
      'Emergency',
    ];
  }
}
